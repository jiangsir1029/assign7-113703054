#include "icon.h"

class IconFactory {

public:
  static Icon NxMColor(Size size, Color color);
};

