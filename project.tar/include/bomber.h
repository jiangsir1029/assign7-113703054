#ifndef BOMBER_H
#define BOMBER_H

#include "gameObject.h"

class Bomber: public GameObject {
public:
    Bomber(Icon icon, Position pos);

    void update() override;
    bool shouldExplode() const;
    void resetTimer();
	std::vector<Position> getExplosionArea() const;
	void explodeNow();
	std::vector<Position> getOccupiedArea() const;
private:
    int _countdown; // 每回合減一，到 0 就爆炸
};

#endif
