#include "bomber.h"
#include <cstdlib>
#include <ctime>

Bomber::Bomber(Icon icon, Position pos)
    : GameObject(icon, pos), _countdown(10) {}

void Bomber::update() {
    // 隨機移動一格
    int dir = rand() % 4;
    switch (dir) {
        case 0: _pos.x()++; break;
        case 1: _pos.x()--; break;
        case 2: _pos.y()++; break;
        case 3: _pos.y()--; break;
    }
    _countdown--;
}

bool Bomber::shouldExplode() const {
    return _countdown <= 0;
}
void Bomber::explodeNow() {
    _countdown = 0;
}
std::vector<Position> Bomber::getExplosionArea() const {
    std::vector<Position> area;
    Position center = _pos;

    int range = std::max((int)_icon.size(), (int)_icon[0].size());  // 高 or 寬

    for (int i = 1; i <= range; ++i) {
        area.push_back({center.x() + i, center.y()});
        area.push_back({center.x() - i, center.y()});
        area.push_back({center.x(), center.y() + i});
        area.push_back({center.x(), center.y() - i});
    }

    area.push_back(center);  //這些都記錄爆炸波及範圍
    return area;
}

void Bomber::resetTimer() {
    _countdown = rand()%15+1;
}
std::vector<Position> Bomber::getOccupiedArea() const {
    std::vector<Position> area;
    for (int dy = -1; dy <= 1; ++dy) {
        for (int dx = -1; dx <= 1; ++dx) {
            int x = _pos.x() + dx;
            int y = _pos.y() + dy;
            area.emplace_back(x, y);
        }
    }
    return area;
}
